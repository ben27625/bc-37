/**
 * Project: Student Management (CRUD)
 * Features:
 *  + Create student
 *  + Read students
 *  + Delete student
 *  + Search student (id + name)
 *  + Update student
 *  + Validate form
 *  + call API
 * Start project
 *  + (PM BA PO) write product requirements document (PRD)
 *  + design
 *  + phân rã lớp đối tượng
 *    (1 lớp SinhVien: maSV, tenSV, dob, email, khoá học, điểm toán, lý,hoá , tinhDiemTrungBinh)
 *  + UI => implement js
 *  + Testing (QC)
 *  + production
 */

var studentList = [];

function createStudent() {
  var isFormValid = validateForm();

  if (!isFormValid) return;

  // 1.lấy input
  var studentId = document.getElementById("txtMaSV").value;
  var fullName = document.getElementById("txtTenSV").value;
  var email = document.getElementById("txtEmail").value;
  var dob = document.getElementById("txtNgaySinh").value;
  var course = document.getElementById("khSV").value;
  var math = +document.getElementById("txtDiemToan").value;
  var physic = +document.getElementById("txtDiemLy").value;
  var chemistry = +document.getElementById("txtDiemHoa").value;

  // 3. tạo object sinh viên mới (input)
  var newStudent = new Student(
    studentId,
    fullName,
    dob,
    email,
    course,
    math,
    physic,
    chemistry
  );

  // gửi request xuống backend kèm theo đối tượng sinh viên mới => thêm sinh viên
  // request = header + body (data)
  axios({
    url: "https://5bd2959ac8f9e400130cb7e9.mockapi.io/api/students",
    method: "POST",
    data: newStudent,
  })
    .then(function (res) {
      console.log(res);
      getStudentList();
    })
    .catch(function (err) {
      console.log(err);
    });
}

function validateForm() {
  // kiểm tra form
  var studentId = document.getElementById("txtMaSV").value;
  var fullName = document.getElementById("txtTenSV").value;

  var isValid = true;

  isValid &=
    required(studentId, "spanMaSV") && length(studentId, "spanMaSV", 6, 9);

  isValid &= required(fullName, "spanTenSV") && string(fullName, "spanTenSV");

  return isValid;
  // nếu isValid = true => form oke
  // nếu isValid = false => form error
}

function renderStudents(data) {
  if (!data) data = studentList;

  var tableHTML = "";
  for (var i = 0; i < data.length; i++) {
    var currentStudent = data[i];
    tableHTML += `<tr>
                <td>${currentStudent.studentId}</td>
                <td>${currentStudent.fullName}</td>
                <td>${currentStudent.email}</td>
                <td>${currentStudent.dob}</td>
                <td>${currentStudent.course}</td>
                <td>${currentStudent.calcGPA().toFixed(2)}</td>
                <td>
                  <button onclick="deleteStudent('${
                    currentStudent.studentId
                  }')" class="btn btn-danger">Xoá</button>

                  <button onclick="getUpdateStudent('${
                    currentStudent.studentId
                  }')" class="btn btn-info">Sửa</button>
                </td>
              </tr>`;
  }
  document.getElementById("tbodySinhVien").innerHTML = tableHTML;
}

async function deleteStudent(studentId) {
  try {
    var res = await axios({
      url:
        "https://5bd2959ac8f9e400130cb7e9.mockapi.io/api/students/" + studentId,
      method: "DELETE",
    });
    console.log(res);
    getStudentList();
  } catch (err) {
    console.log(err);
  }
}

function findById(studentId) {
  for (var i = 0; i < studentList.length; i++) {
    console.log(studentList[i]);
    if (studentList[i].studentId === studentId) {
      return i;
    }
  }

  return -1;
}

function setStudentList() {
  var studentListJSON = JSON.stringify(studentList);
  localStorage.setItem("SL", studentListJSON);
}

async function getStudentList() {
  // return promise
  // gửi request xuống backend => ds sinh viên
  var promise = axios({
    url: "https://5bd2959ac8f9e400130cb7e9.mockapi.io/api/students",
    method: "GET",
  });

  try {
    var response = await promise;
    studentList = mapData(response.data);
    renderStudents();
    console.log("done");
  } catch (err) {
    console.log(err);
  }

  /**
   *  Promise:
   *    - Pending
   *    - Fulfill
   *    - Reject
   */
}

// input: list local => output: list mới
function mapData(studentListLocal) {
  var result = [];
  for (var i = 0; i < studentListLocal.length; i++) {
    var oldStudent = studentListLocal[i];
    var newStudent = new Student(
      oldStudent.studentId,
      oldStudent.fullName,
      oldStudent.dob,
      oldStudent.email,
      oldStudent.course,
      oldStudent.math,
      oldStudent.physic,
      oldStudent.chemistry
    );
    result.push(newStudent);
  }
  return result;
}

function searchStudents() {
  // document.getElementsByClassName("form-control")  trả về array
  // document.querySelectorAll(".form-control"); trả về array
  // document.getElementById("")

  var keyword = document.querySelector("#txtSearch").value.toLowerCase().trim();

  var result = [];

  for (var i = 0; i < studentList.length; i++) {
    var studentId = studentList[i].studentId;
    var studentName = studentList[i].fullName.toLowerCase();

    if (studentId === keyword || studentName.includes(keyword)) {
      result.push(studentList[i]);
    }
  }

  // result = [student1, student2,...]

  renderStudents(result);
}

window.onload = function () {
  // code sẽ chạy khi window đc load lên
  console.log("window load");
  getStudentList();
};

// update phần 1: lấy thông sinh viên show lên trên form
function getUpdateStudent(studentId) {
  axios({
    url:
      "https://5bd2959ac8f9e400130cb7e9.mockapi.io/api/students/" + studentId,
    method: "GET",
  })
    .then(function (res) {
      var student = res.data;
      // đổ thông tin của student lên input
      document.getElementById("txtMaSV").value = student.studentId;
      document.getElementById("txtTenSV").value = student.fullName;
      document.getElementById("txtEmail").value = student.email;
      document.getElementById("txtNgaySinh").value = student.dob;
      document.getElementById("khSV").value = student.course;
      document.getElementById("txtDiemToan").value = student.math;
      document.getElementById("txtDiemLy").value = student.physic;
      document.getElementById("txtDiemHoa").value = student.chemistry;

      // hiện nút lưu thay đổi, ẩn nút thêm
      document.getElementById("btnUpdate").style.display = "inline-block";
      document.getElementById("btnCreate").style.display = "none";

      // disable input mã sinh viên
      document.getElementById("txtMaSV").disabled = true;
    })
    .catch(function (err) {
      console.log(err);
    });
}

// update phần 2:  cho người dùng sửa thông tin trên form => nhấn nút lưu thay đổi => chạy hàm update
function updateStudent() {
  var studentId = document.getElementById("txtMaSV").value;
  var fullName = document.getElementById("txtTenSV").value;
  var email = document.getElementById("txtEmail").value;
  var dob = document.getElementById("txtNgaySinh").value;
  var course = document.getElementById("khSV").value;
  var math = +document.getElementById("txtDiemToan").value;
  var physic = +document.getElementById("txtDiemLy").value;
  var chemistry = +document.getElementById("txtDiemHoa").value;

  // tạo đối tượng mới
  var newStudent = { fullName: fullName };

  axios({
    url:
      "https://5bd2959ac8f9e400130cb7e9.mockapi.io/api/students/" + studentId,
    method: "PUT",
    data: newStudent,
  })
    .then(function (res) {
      getStudentList();

      // hiện lại nút thêm, ẩn nút lưu
      document.getElementById("btnUpdate").style.display = "none";
      document.getElementById("btnCreate").style.display = "block";

      // clear toàn bộ input
      document.getElementById("btnReset").click();

      // mở lại input mã sinh viên
      document.getElementById("txtMaSV").disabled = false;
    })
    .catch(function (err) {
      console.log(err);
    });
}
//primitive type: string, number ,undefined,null,boolean
var a = 10;
var b = a;

b = 30;

// console.log(a, b);

// reference type: object

var student1 = {
  name: "hieu",
  age: 12,
  father: {
    name: "Liêm",
    age: 61,
  },
};

// var student2 = Object.assign({}, student1);

var student2 = JSON.parse(JSON.stringify(student1));

// var student2 = student1;

student2.father.name = "Dũng";

// console.log(student1, student2);

// VALIDATION FORM

// required
function required(val, spanId) {
  if (val.length === 0) {
    document.getElementById(spanId).innerHTML = "*Trường này bắt buộc nhập";
    return false;
  }

  document.getElementById(spanId).innerHTML = "";
  return true;
}

// min length ,max length
function length(val, spanId, min, max) {
  if (val.length < min || val.length > max) {
    document.getElementById(
      spanId
    ).innerHTML = `*Độ dài phải từ ${min} tới ${max} kí tự`;
    return false;
  }

  document.getElementById(spanId).innerHTML = "";
  return true;
}

// pattern check name
function string(val, spanId) {
  var pattern = /^[A-z ]+$/g;
  if (pattern.test(val)) {
    document.getElementById(spanId).innerHTML = "";
    return true;
  }

  document.getElementById(spanId).innerHTML = `*Chỉ chấp nhận kí tự từ a tới z`;
  return false;
}

// pattern check email

// pattern check number

// synchronous: đồng bộ
// var a = 5;
// var b = 10;
// var sum = a + b;
// console.log("tổng");
// console.log(sum);

// asynchronous : bất đồng bộ
// callback: function a truyền vào function b dưới dạng tham số đầu vào

// setTimeout(function () {
//   console.log("hello");
// }, 2000);

// setTimeout(function () {
//   console.log("hello 2");
// }, 3000);

// setTimeout(function () {
//   console.log("hello 4");
// }, 0);

// console.log("hello 5");
// console.log("hello 6");
// console.log("hello 7");

// setTimeout(function () {
//   console.log("hello 8");
// }, 1000);

// // for(var i = 0; i < 10000000000000000000000000000000; i++){
// //   console.log('hqweqwi')
// // }

// function test() {
//   console.log("a");
// }

// function test2() {
//   console.log("b");
// }

// function test3() {
//   console.log("c");

//   function test4() {
//     console.log("d");

//     function test5() {
//       console.log("e");
//     }
//     test5();
//   }

//   test4();
// }

// test();
// test2();
// test3();

// promise : object JS

// - pending -fulfill -reject

// var p1 = new Promise(function (resolve, reject) {
//   // code....
//   setTimeout(function () {
//     var data = [{ name: "hieu", age: 12 }];
//     resolve(data);
//   }, 2000);

//   // var err = { code: "FAIL" };
//   // reject(err);
// });

// var p2 = new Promise(function (resolve, reject) {
//   // code....
//   setTimeout(function () {
//     var data = [{ name: "Admin" }, { name: "User" }];
//     resolve(data);
//   }, 4000);
// });

// var p1 = axios(); // users
// var p2 = axios(); // loại user

// var p3 = Promise.all([p1, p2]);

// p3.then(function (res) {
//   console.log(res); // res => [response p1, response p2]
// });

// p2.then(function (res) {
//   console.log("response p2", res);
// }).catch();

// p1.then(function (res) {
//   console.log("response p1", res);
// }).catch(function (err) {
//   console.log("error", err);
// });

// promise chaining
// axios() // (1)
//   .then(function (res) {
//     var id = res.id;
//     return axios(); // (2)
//   })
//   .then(function (res) {
//     return axios(); // (3)
//   })
//   .then()
//   .catch(function (err) {
//     console.log(err);
//   });

// async await = then catch

// var res1 = await axios(); //(1)
// var res2 = await axios({ id: res1.id });
// await axios();

// axios().then(); //(1)
// axios().then(); //(2)
// axios().then(); //(3)
// axios().then(); //(4)

// ex: cho một mảng số nguyên, kiểm tra xem trong mảng có 2 số nào cộng lại = 10 ko?
function ex1() {
  var arr = [3, 9, 2, 7, 5, 10, 19, 5, 7];
  var obj = {};

  for (var i = 0; i < arr.length; i++) {
    var currentNum = arr[i]; //7
    var foundNum = 10 - currentNum; // 3

    // kiểm tra foundNum có nằm trong obj => return "có"
    if (foundNum in obj) {
      console.log(currentNum, foundNum);
      delete obj[foundNum];
    } else {
      // không có => bỏ currentNum vào obj => đi tiếp
      obj[currentNum] = true;
    }
  }
  console.log("không");
}

ex1();

//ex2 : uniq [1,2,2,3,2,4] => [1,2,3,4]
function ex2() {
  var arr = [1, 2, 2, 3, 2, 4];
  var obj = {};
  var res;
  for (var i = 0; i < arr.length; i++) {
    var num = arr[i]; //2
    if (num in obj) continue;
    obj[num] = true;
    //obj[2]= true => obj =  {1: true, 2: true, 3: true, 4:true}
  }
  res = Object.keys(obj); // {1: true, 2: true, 3: true, 4:true} => ["1","2","3","4"]
  // ["1","2","3","4"] => [1,2,3,4]
  for (var i = 0; i < res.length; i++) {
    res[i] = +res[i];
  }
  console.log(res);
}
ex2();
var obj = { name: "hieu", age: 12 };

// dynamic key

var keyword = "abc";

if (keyword in obj) {
  console.log(obj[keyword]);
} else {
  console.log("Keyword ko đúng");
}

// = obj["abc"]

console.log(obj.name, obj["age"]);
