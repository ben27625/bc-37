// 1. Đoạn code login , chờ user nhập username, password => nhấn nút => chạy code
// 2. cần có cách để tái sử dụng code
// => function (hàm)

// x,y: tham số đầu vào của calcSum
// function calcSum(x, y) {
//   var sum = x + y;
//   console.log(sum);
// }

// function showMessage(text) {
//   console.log(text);
// }

// // đối số
// calcSum(2, 4);
// calcSum(4, 5);
// calcSum(10, 20);

// var text = "Hello world!!";

// showMessage(text);

//scope:  phạm vi truy cập biến ,
// global scope = toàn cục, function scope = cục bộ

var c = 4;
var d = 1;
var sum2 = c + d;
console.log(sum2);

// function có giá trị trả về, trong trường ko trả giá trị ra ngoài => undefined
// function đã return về giá trị => function xong, những đoạn code dưới return sẽ ko bh đc chạy
// function chỉ đc phép return 1 giá trị

function calcSum(x, y) {
  var sum = x + y;
  return sum;
  console.log("1123");
  console.log("1123");
  console.log("1123");
  console.log("1123");
  console.log("1123");
  console.log("1123");
}

var res = calcSum(5, 6);
console.log(calcSum(10, 12));
console.log(calcSum());

console.log(res);
//code logic
/**
 * INPUT: điểm chuẩn, môn1, môn2 ,môn3,khu vực(A,B,C,X), đối tượng (1,2,3,0)
 *
 * PROCESS:
 *    1. lấy input (hardcode)
 *    2. tính điểm ưu tiên theo khu vực
 *    3. tính điểm ưu tiên theo đối tượng
 *    4. tính tổng điểm = môn1 + môn2 + môn3 + điểm KV + điểm ĐT
 *    5. check kết quả , tổng điểm >= điểm chuẩn và ko có môn nào = 0= > đâu;
 *
 *
 * OUTPUT: tính điểm , kết quả đậu rớt
 */

function calcAreaGrade(area) {
  switch (area) {
    case "A":
      return 2;
    case "B":
      return 1;
    case "C":
      return 0.5;
    default:
      return 0;
  }
}

function calcTypeGrade(type) {
  switch (type) {
    case 1:
      return 2.5;
    case 2:
      return 1.5;
    case 3:
      return 1;
    default:
      return 0;
  }
}

function ex1() {
  var standardGrade = 22;
  var sub1 = 5;
  var sub2 = 10;
  var sub3 = 7;
  var area = "C";
  var type = 1;

  var areaGrade = calcAreaGrade(area);
  var typeGrade = calcTypeGrade(type);
  var totalGrade = 0;

  totalGrade = sub1 + sub2 + sub3 + areaGrade + typeGrade;

  if (totalGrade >= standardGrade && sub1 !== 0 && sub2 !== 0 && sub3 !== 0) {
    console.log("Đậu");
  } else {
    console.log("Rớt");
  }
}

ex1();

function ex2() {
  var kW;
  var totalAmount = 0;

  if (kW <= 50) {
    totalAmount = kW * 500;
  } else if (kW <= 100) {
    totalAmount = 50 * 500 + (kW - 50) * 650;
  } else if (kW <= 200) {
    totalAmount = 50 * 500 + 50 * 650 + (kW - 100) * 850;
  } else if (kW <= 350) {
    totalAmount = 50 * 500 + 50 * 650 + 100 * 850 + (kW - 200) * 1100;
  } else {
    totalAmount =
      50 * 500 + 50 * 650 + 100 * 850 + 150 * 1100 + (kW - 350) * 1300;
  }
  console.log(totalAmount);
}
