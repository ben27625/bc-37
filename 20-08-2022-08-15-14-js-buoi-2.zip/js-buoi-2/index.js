// // toán tử so sánh

// // biểu thức so sánh => boolean
// console.log(5 > 2); // true
// console.log(5 < 2); // false
// console.log(5 == 5); // true
// console.log(5 != 3); // true
// console.log(5 >= 5); // true;
// console.log(4 <= 3); // false

// console.log(5 === "5"); //false

// console.log(4 !== "4"); //true

// // toán tử logic : ! , &&, ||

// var a = true;
// console.log(!!!a);

// // biểu thức logic
// console.log(!(5 > 2) && 4 < 6); //false
// console.log(5 < 2 && 4 < 6 && 7 < 10); // false

// console.log(5 > 2 || 4 < 6); // true
// console.log(5 < 2 || 4 < 6 || 7 < 10); // true

// //cấu trúc câu điều kiện

// // if(biểu thức điều kiện){
// //     //code sẽ chạy nếu đúng điều kiện
// // }else{
// //     // code sẽ chạy nếu điều kiện sai
// // }

// var a = -5;

// if (a < 0) {
//   console.log(a, "là số âm");
//   a = -a;
// } else {
//   console.log(a, "là số dương");
// }

// console.log(a);

// /**
//  * INPUT: số tiền phải trả , số tiền đã trả
//  *
//  * PROCESS:
//  *     1.lấy input, creditCardBalance = 10000000, payment = 6000000
//  *     2. tính balance = tổng phải trả - đã trả
//  *     3. kiểm tra nếu balance > 0 thì tính phạt 1.5% * nợ
//  *     4. ngược lại, nếu ko có nợ, thì báo là đã thanh toán hoàn tất
//  *
//  * OUTPUT: Tiền phạt
//  */

// var creditCardBalance = 10000000;
// var payment = 6000000;
// var balance = creditCardBalance - payment;
// var penalty = 0;

// if (balance > 0) {
//   penalty = (balance * 1.5) / 100;
//   console.log("tiền phạt:", penalty);
// } else {
//   console.log("Thanh toán đầy đủ!");
// }

// var workingHours = 50;
// var wage = 10;
// var total = 0;

// if (workingHours <= 40) {
//   total = workingHours * wage;
// } else {
//   total = 40 * wage + (workingHours - 40) * 1.5 * wage;
// }

// console.log(total);

// var fullName = "Đặng Trung Hiếu";
// var math = 8;
// var physics = 8;
// var chemistry = 8;

// var gpa = (math + physics + chemistry) / 3;

// if (gpa >= 8.5) console.log("Gioi");
// else if (gpa >= 6.5) console.log("khá");
// else if (gpa >= 5) console.log("TB");
// else console.log("yếu");

// var productName = "Samsung ZFlip 4";
// var quantity = 120;
// var price = 1500;
// var totalAmount = 0;

// if (quantity <= 50) {
//   totalAmount = quantity * price;
// } else if (quantity > 100) {
//   totalAmount =
//     50 * price + 50 * price * 0.92 + (quantity - 100) * price * 0.88;
// } else if (quantity > 50) {
//   totalAmount = 50 * price + (quantity - 50) * price * 0.92;
// }
// console.log(totalAmount);

// phép toán 3 ngôi (ternary operator)

var a = 5;

if (a > 0) {
  console.log("a là số dương");
  if (a % 2 === 0) {
    console.log("a là số chẵn");
  } else {
    console.log("a là số lẻ");
  }
} else {
  console.log("a là số âm");
}

// a > 0 ? console.log("a là số dương") : console.log("a là số âm");

var text = "";

var isLogin = false;

// if( isLogin === true ){
//     text = "Xin chào"
// } else {
//     text = "Vui lòng đăng nhập"
// }


text = isLogin === true ? "Xin chào" : "Vui lòng đăng nhập";

console.log(text);
