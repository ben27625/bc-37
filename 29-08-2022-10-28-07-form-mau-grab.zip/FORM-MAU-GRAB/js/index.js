/**
 * INPUT: loại xe, quãng đường, tg chờ
 *
 *
 * PROCESS:
 *      1. lấy input (DOM):
 *          + km, tgcho => input => value
 *          + loại xe => 3 input radio => checked => value (grabCar)
 *      2. chọn bảng giá (câu điều kiện). tạo 4 biến p1= 8000,p2 = 7500,p3 =7000,p4= 2000
 *      3. tính tiền = tiền km + tiền chờ
 *      4. In ra màn hình
 *
 * OUTPUT: tổng tiền
 *
 *
 */

function calcTaxiFee() {
  //code: tính tiền taxi
  var km = +document.getElementById("txtKM").value;
  var waitingTime = +document.getElementById("txtWaitingTime").value;
  var grabType;
  var p1;
  var p2;
  var p3;
  var p4;

  var totalPrice;
  var priceByKm;
  var priceByWaitingTime;

  var radioGrabCar = document.getElementById("radioGrabCar");
  var radioGrabSUV = document.getElementById("radioGrabSUV");
  var radioGrabBlack = document.getElementById("radioGrabBlack");

  if (radioGrabCar.checked ) {
    grabType = 1;
  } else if (radioGrabSUV.checked ) {
    grabType = 2;
  } else if (radioGrabBlack.checked ) {
    grabType = 3;
  } else {
    alert("Vui lòng chọn loại xe");
    return;
  }

  // check bảng giá
  switch (grabType) {
    case 1:
      p1 = 8000;
      p2 = 7500;
      p3 = 7000;
      p4 = 2000;
      break;
    case 2:
      p1 = 9000;
      p2 = 8500;
      p3 = 8000;
      p4 = 3000;
      break;
    case 3:
      p1 = 10000;
      p2 = 9500;
      p3 = 9000;
      p4 = 3500;
      break;
    default:
      return;
  }

  // tính tiền
  priceByWaitingTime = Math.floor(waitingTime / 3) * p4;

  if (km < 1) {
    priceByKm = p1;
  } else if (km < 19) {
    priceByKm = p1 + (km - 1) * p2;
  } else {
    priceByKm = p1 + 18 * p2 + (km - 19) * p3;
  }

  totalPrice = priceByKm + priceByWaitingTime;
  console.log(totalPrice);

  document.getElementById("divThanhTien").style.display = "block";
  document.getElementById("divThanhTien").style.color = "#ffffff";
  document.getElementById("divThanhTien").style.backgroundColor = "#ff0000";

  document.getElementById("xuatTien").innerHTML = totalPrice;

  document.getElementById("txtKM").placeholder = "ABCJWSKLJADS";

  // 1. parseInt, parseFLoat
  //   km = parseFloat(km);
  //   waitingTime = parseFloat(waitingTime);

  // 2. * 1
  //   km = km * 1;
  //   waitingTime = waitingTime * 1;
}

// events: click, input, mouseover, mouseout, keyup, keydown, keypress..

// event handler:  function sẽ chạy khi sự kiện diễn ra

// truthy  / falsy: 0, "", null, undefined, NaN, false
