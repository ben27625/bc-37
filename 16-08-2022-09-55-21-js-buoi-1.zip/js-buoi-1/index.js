console.log("hello world 2");
//variables
//  cho a = 5, b = 7 => ax + by = 5

var name = "Oliver Dang";
var age = 12;

age = 13;

// camelCase
// var phoneNumber = "0334643124";
/**
 * qưehjkqwhejkqe
 * qưhekjhqwe
 * qjweklqwje
 * qjweklqjwe
 */
var dateOfBirth = "09/06/1995";

name = "Edward Dang";
console.log(age);

console.log(name);
console.log(name);
console.log(name);
console.log(name);
console.log(name);

// kiểu dữ liệu cơ bản (primitive types)
var number = 20.5;
var email = "hieu@gmail.com";
var isLocked = false;
var myWifeName = null;
var mySonName;

// toán tử

var r1 = 4 + 2; // r1= 6
var r2 = 4 - 2;
var r3 = 4 * 2;
var r4 = 3 / 2;
var r5 = 13 % 3; // 1

// r1 + 3;

// r2++;
// <=> r2 = r2 + 1
// r3--;
// <=> r3= r3 -1

var r6 = r1++ + 2; //8

var r7 = ++r1 + 2; // 10

r7 = r7++ + 0; //10

console.log(r1, r6, r7);

// phép gán

var r8 = 10;
r8 += 3;
// r8 = r8 + 3
r8 -= 5;
// r8 = r8 - 5 = 8
r8 *= 4;
// r8 = r8 * 4 = 32
r8 /= 2;
// r8 = r8 / 2 = 16

r8 %= 3;
// r8 = r8 % 3;

console.log(r8);

/**
 *
 * a = 9 b = 7
 * b = 16, a = 10
 * c = 37, b = 17 , a = 10
 * c= 38, b= 66, a= 11
 *
 *
 *
 * sum = 22.1
 * c = 4.7
 * b = 6.7
 * a = 40.2
 *
 */

/**
 * Sơ đồ 3 khối
 * Input: n có 2 chữ số
 *
 *
 * process:
 *  1.tìm cách lấy n : var n = 24;
 *  2. tách 2 kí số
 *     n1 = n % 10 = 4
 *     n2 = Math.floor(n / 24) = 2
 *  3. result = n1 + n2, console.log result
 *
 * output: tổng 2 kí số của n (ex : 41 => 5)
 *
 */

var n = 31;
var n1 = n % 10;
var n2 = Math.floor(n / 10);
var result = n1 + n2;

console.log("Tồng 2 kí số là:",result);
